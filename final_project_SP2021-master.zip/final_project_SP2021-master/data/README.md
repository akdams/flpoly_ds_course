# Data Description: Super Bowl Data

We use the `super_bowl.csv` dataset available at 
<https://github.com/reisanar/datasets/blob/master/super_bowl.csv>

This dataset includes information on specfic Super Bowl stats, important names and locations, and other pieces of interesting data.

The data fields included are: Date, SB, Attendance, QB Winner/Loser, Coach Winner/Loser, Team Winner/Loser, Points for Winner/Loser, MVP,
Stadium, City, State, Point Difference, and the seven different referees (Referee, Umpire, Head Linesman, Line Judge, Field Judge, Back
Judge, Side Judge).

We have also updated the provided dataset to be up to date with the most recent Super Bowl that occured in early 2021.
