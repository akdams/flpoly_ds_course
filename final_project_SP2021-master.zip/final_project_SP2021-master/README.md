# Final Project for Intro to Data Science

## Spring 2020

Team members: 

- Student 1 [Logan Zorrilla](https://github.com/lzorrilla)

- Student 2 [Austin Adams](https://github.com/akdams)

- Student 3 [Emily Pelletier](https://github.com/epelletier93)


We will be using the dataset: `super_bowl.csv` available at 
<https://github.com/reisanar/datasets/blob/master/super_bowl.csv>
